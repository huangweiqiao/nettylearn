
package example2;

public class Customer {
    private Person person;
    private String street;
    private String city;
    private String state;
    private Object zip;
    private String phone;
    public void setPhone(String phone) {
        this.phone = phone;
    }
}
