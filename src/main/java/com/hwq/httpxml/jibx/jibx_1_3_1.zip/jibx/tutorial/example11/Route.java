
package example11;

import java.util.ArrayList;

public class Route
{
    private Airport from;
    private Airport to;
    private ArrayList flights;
}
