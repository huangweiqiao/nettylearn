
package example16;

public class Person extends Identity {
    public String firstName;
    public String lastName;
}
