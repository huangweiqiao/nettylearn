
package example3;

public class Person {
    private String firstName;
    private String lastName;
    private int customerNumber;
}
