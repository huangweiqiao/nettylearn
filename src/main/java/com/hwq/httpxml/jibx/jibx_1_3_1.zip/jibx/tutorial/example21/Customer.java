
package example21;

public class Customer {
    private Name name;
    private String street;
    private String city;
    private String state;
    private Integer zip;
}
