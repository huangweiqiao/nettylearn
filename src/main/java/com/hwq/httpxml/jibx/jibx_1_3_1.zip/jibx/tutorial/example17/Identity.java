
package example17;

public class Identity {
    public int customerNumber;
}
